#!/bin/sh

while :; do sleep 0.5; node server.js; done
