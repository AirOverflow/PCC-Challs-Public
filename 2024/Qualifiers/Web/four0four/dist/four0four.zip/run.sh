#!/bin/bash

&>/dev/null /usr/sbin/apachectl -DFOREGROUND -k start