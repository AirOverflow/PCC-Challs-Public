#!/bin/bash

node app.js
sleep 300